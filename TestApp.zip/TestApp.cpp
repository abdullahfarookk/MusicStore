#include "stdafx.h"
#include <iostream>
#include <bass.h>
#include <iomanip>
#include <string>
#include <fstream>
#include "Header.h"
#include <Windows.h>
#include <cstdlib>




using namespace std;


int main()
{
	library obj;

	system("Color f0");
	int a;
	string choice;
	
	Loading();
	for (int i = 0; i < 1; i++){
		LoginMenu(&a);
		if (a == 1)
			signUp();
		else if (a == 2)
			signIn();
	}
	do
	{
		system("cls");
		MainMenu(&a);
		if (a == 1)
			infoAccount();
		else if (a == 2){
			
			obj.Display();
		}
		else if (a==3)
		{
			
			
		}
		else if (a==4)
		{

		}
		else if (a==5)
		{
			obj.Add();
		}
		else if (a == 6){
			break;
		}
		else
		{
			cout << "\n\t\t\tInvalid Entry.........";
		}

	}
			while (true);
	system("pause");
}


